

################## Install Lambda Stack

# Update Ubuntu
sudo apt-get update && sudo apt-get dist-upgrade -y && sudo apt update && sudo apt dist-upgrade -y && sudo apt-get autoremove -y && sudo apt autoremove -y && \

# Add Lambda Repository
LAMBDA_REPO=$(mktemp) && \
wget -O${LAMBDA_REPO} https://lambdalabs.com/static/misc/lambda-stack-repo.deb && \
sudo dpkg -i ${LAMBDA_REPO} && rm -f ${LAMBDA_REPO} && \

# Update Repositories
sudo apt update && sudo apt-get update && \

# Install Lambda Stack
sudo apt-get install -y lambda-stack-cuda -y && \

# Reboot the System
sudo reboot

