

##################### Install venv myLab #####################

# Update Ubuntu
sudo apt-get update && sudo apt-get dist-upgrade -y && sudo apt update && sudo apt dist-upgrade -y && sudo apt-get autoremove -y && sudo apt autoremove -y && \

# Install Tools
#sudo python3 -m pip install --upgrade pip && \
#echo "" && \
#sudo python3 -m pip install virtualenv && \
sudo apt-get install cmake -y && \
sudo apt-get install python3-pip -y && \
echo "" && \
sudo apt-get install python3-venv -y && \
echo "" && \

# Create venv with ssp access
python3 -m venv venv --system-site-packages && \ 
#--system-site-packages && \
echo "" && \
echo "Installing virtual environment ..." && \
echo "" && \
source venv/bin/activate && \

# Add venv to the PATH
echo """
# Add venv PATH
export PATH=/root/.local/bin:$PATH

""" >> ~/.bashrc && \
echo "" && \
echo "Adding virtual environment to the PATH ..." && \
echo "" && \
echo "Installing virtual environment resources ..." && \
echo "" && \

# Installs the attached packagelist
python -m ipykernel install --user --name=venv
pip3 install -r myPlus.txt --ignore-installed

# this may also help
#pip3 install -r theplus.txt --ignore-installed
#python -m ipykernel install --user --name=venv <--
#python -m jupyter install --user --name=venv
#python -m pip install ipykernel install --user --name=venv
#python -m pip install jupyter install --user --name=venv

#python -m pip install jupyter

