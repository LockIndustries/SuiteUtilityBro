
#################### Install  Dependencies and Utilities ####################

# Update Ubuntu
sudo apt-get update && sudo apt-get dist-upgrade -y && sudo apt update && sudo apt dist-upgrade -y && sudo apt-get autoremove -y && sudo apt autoremove -y && \

## Install Dependency Libraries and Utilities
sudo apt-get install libgl1-mesa-glx libegl1-mesa libxrandr2 libxrandr2 libxss1 libxcursor1 libxcomposite1 libasound2 libxi6 libxtst6 -y && \

sudo apt-get install curl gvfs gvfs-common gvfs-daemons gvfs-libs gconf-service gconf2 gconf2-common -y && \

## Install Node
#sudo apt-get purge nodejs npm -y && \
curl -sL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt-get install -y nodejs

sudo apt-get install gvfs-bin psmisc libpango1.0-0 node.js pciutils xclip xsel figlet -y && \

sudo apt-get install cmake tilix net-tools screen htop links2 elinks hddtemp lm-sensors pv -y && \

sudo apt-get install micro -y && \

snap install atom --classic && \

snap install discord && \ 

snap install spotify && \

sudo reboot now

#sudo dpkg -i jdk-11.0.7_linux-x64_bin.deb

#sudo dpkg -i jdk-14.0.1_linux-x64_bin.deb


